from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from typing import List, Optional
from db import get_db
from models.autocare_models import Produto, Categoria, MovimentoEstoque, Fornecedor
from schemas.schemas_estoque import (
    ProdutoCreate,
    ProdutoUpdate,
    ProdutoResponse,
    ProdutoList,
    CategoriaCreate,
    CategoriaUpdate,
    CategoriaResponse,
    MovimentacaoEstoqueCreate,
    MovimentacaoEstoqueResponse
)

router = APIRouter()

# =============================================================================
# PRODUTOS
# =============================================================================

@router.get("/produtos", response_model=List[ProdutoList])
def listar_produtos(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    categoria_id: Optional[int] = None,
    fornecedor_id: Optional[int] = None,
    estoque_baixo: bool = False,
    ativo: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """Listar produtos com filtros opcionais"""
    query = db.query(Produto)
    
    if search:
        query = query.filter(
            or_(
                Produto.codigo.ilike(f"%{search}%"),
                Produto.nome.ilike(f"%{search}%"),
                Produto.descricao.ilike(f"%{search}%")
            )
        )
    
    if categoria_id:
        query = query.filter(Produto.categoria_id == categoria_id)
    
    if fornecedor_id:
        query = query.filter(Produto.fornecedor_id == fornecedor_id)
    
    if estoque_baixo:
        query = query.filter(Produto.estoque_atual <= Produto.estoque_minimo)
    
    # Se não for informado `ativo`, por padrão retornamos apenas produtos ativos.
    if ativo is None:
        query = query.filter(Produto.ativo == True)
    else:
        query = query.filter(Produto.ativo == ativo)
    
    produtos = query.offset(skip).limit(limit).all()
    # Enriquecer cada produto com o nome do fornecedor (quando presente)
    for p in produtos:
        try:
            if p.fornecedor_id:
                f = db.query(Fornecedor).filter(Fornecedor.id == p.fornecedor_id).first()
                p.fornecedor_nome = f.nome if f else None
            else:
                p.fornecedor_nome = None
        except Exception:
            p.fornecedor_nome = None
    return produtos

@router.get("/produtos/{produto_id}", response_model=ProdutoResponse)
def buscar_produto(produto_id: int, db: Session = Depends(get_db)):
    """Buscar produto por ID"""
    produto = db.query(Produto).filter(Produto.id == produto_id).first()
    if not produto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produto não encontrado"
        )
    # Enriquecer com nome do fornecedor quando disponível
    try:
        if produto.fornecedor_id:
            f = db.query(Fornecedor).filter(Fornecedor.id == produto.fornecedor_id).first()
            produto.fornecedor_nome = f.nome if f else None
        else:
            produto.fornecedor_nome = None
    except Exception:
        produto.fornecedor_nome = None
    return produto

@router.post("/produtos", response_model=ProdutoResponse, status_code=status.HTTP_201_CREATED)
def criar_produto(produto_data: ProdutoCreate, db: Session = Depends(get_db)):
    """Criar novo produto"""
    
    # Verificar se código já existe
    existing = db.query(Produto).filter(Produto.codigo == produto_data.codigo).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Código do produto já existe"
        )
    
    # Verificar se categoria existe (se fornecida)
    if produto_data.categoria_id:
        categoria = db.query(Categoria).filter(Categoria.id == produto_data.categoria_id).first()
        if not categoria:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Categoria não encontrada"
            )
    
    # Verificar se fornecedor existe (se fornecido)
    if produto_data.fornecedor_id:
        fornecedor = db.query(Fornecedor).filter(Fornecedor.id == produto_data.fornecedor_id).first()
        if not fornecedor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Fornecedor não encontrado"
            )
    
    produto = Produto(**produto_data.dict())
    db.add(produto)
    db.commit()
    db.refresh(produto)
    # Enriquecer com nome do fornecedor (se informado)
    try:
        if produto.fornecedor_id:
            f = db.query(Fornecedor).filter(Fornecedor.id == produto.fornecedor_id).first()
            produto.fornecedor_nome = f.nome if f else None
        else:
            produto.fornecedor_nome = None
    except Exception:
        produto.fornecedor_nome = None
    return produto

@router.put("/produtos/{produto_id}", response_model=ProdutoResponse)
def atualizar_produto(
    produto_id: int,
    produto_data: ProdutoUpdate,
    db: Session = Depends(get_db)
):
    """Atualizar produto existente"""
    produto = db.query(Produto).filter(Produto.id == produto_id).first()
    if not produto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produto não encontrado"
        )
    # Verificar se código já existe em outro produto
    if produto_data.codigo:
        existing = db.query(Produto).filter(
            and_(
                Produto.codigo == produto_data.codigo,
                Produto.id != produto_id
            )
        ).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Código já existe em outro produto"
            )
    # Atualizar apenas campos não nulos; converter string vazia em None
    update_data = produto_data.dict(exclude_unset=True)
    for k, v in list(update_data.items()):
        if isinstance(v, str) and v.strip() == "":
            update_data[k] = None
    for key, value in update_data.items():
        setattr(produto, key, value)
    db.commit()
    db.refresh(produto)
    # Enriquecer com nome do fornecedor (quando disponível)
    try:
        if produto.fornecedor_id:
            f = db.query(Fornecedor).filter(Fornecedor.id == produto.fornecedor_id).first()
            produto.fornecedor_nome = f.nome if f else None
        else:
            produto.fornecedor_nome = None
    except Exception:
        produto.fornecedor_nome = None
    return produto


@router.delete("/produtos/{produto_id}", response_model=ProdutoResponse)
def deletar_produto(produto_id: int, db: Session = Depends(get_db)):
    """Excluir (soft-delete) produto: marcar como inativo"""
    produto = db.query(Produto).filter(Produto.id == produto_id).first()
    if not produto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produto não encontrado"
        )
    # Soft-delete: marcar como inativo
    produto.ativo = False
    db.commit()
    db.refresh(produto)
    try:
        produto.fornecedor_nome = produto.fornecedor.nome if getattr(produto, 'fornecedor', None) else None
    except Exception:
        produto.fornecedor_nome = None
    return produto

# =============================================================================
# CATEGORIAS
# =============================================================================

@router.get("/categorias", response_model=List[CategoriaResponse])
def listar_categorias(
    skip: int = 0,
    limit: int = 100,
    ativo: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """Listar categorias"""
    query = db.query(Categoria)
    
    if ativo is not None:
        query = query.filter(Categoria.ativo == ativo)
    
    categorias = query.offset(skip).limit(limit).all()
    return categorias

@router.post("/categorias", response_model=CategoriaResponse, status_code=status.HTTP_201_CREATED)
def criar_categoria(categoria_data: CategoriaCreate, db: Session = Depends(get_db)):
    """Criar nova categoria"""
    
    # Verificar se nome já existe
    existing = db.query(Categoria).filter(Categoria.nome == categoria_data.nome).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nome da categoria já existe"
        )
    
    categoria = Categoria(**categoria_data.dict())
    db.add(categoria)
    db.commit()
    db.refresh(categoria)
    return categoria

# =============================================================================
# MOVIMENTAÇÃO DE ESTOQUE
# =============================================================================

@router.get("/movimentos", response_model=List[MovimentacaoEstoqueResponse])
def listar_movimentos_estoque(
    skip: int = 0,
    limit: int = 100,
    produto_id: Optional[int] = None,
    tipo: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Listar movimentações de estoque"""
    query = db.query(MovimentoEstoque)
    
    if produto_id:
        query = query.filter(MovimentoEstoque.item_id == produto_id)
    
    if tipo:
        query = query.filter(MovimentoEstoque.tipo == tipo)
    
    movimentos = query.order_by(MovimentoEstoque.data_movimentacao.desc()).offset(skip).limit(limit).all()
    return movimentos

@router.post("/movimentos", response_model=MovimentacaoEstoqueResponse, status_code=status.HTTP_201_CREATED)
def criar_movimento_estoque(movimento_data: MovimentacaoEstoqueCreate, db: Session = Depends(get_db)):
    """Registrar movimento de estoque"""
    
    # Verificar se produto existe
    produto = db.query(Produto).filter(Produto.id == movimento_data.item_id).first()
    if not produto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produto não encontrado"
        )
    
    # Verificar se fornecedor existe (se fornecido)
    if movimento_data.fornecedor_id:
        fornecedor = db.query(Fornecedor).filter(Fornecedor.id == movimento_data.fornecedor_id).first()
        if not fornecedor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Fornecedor não encontrado"
            )
    
    # Verificar se há estoque suficiente para saída
    if movimento_data.tipo == "SAIDA":
        if produto.quantidade_atual < movimento_data.quantidade:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Estoque insuficiente para esta operação"
            )
    
    # Criar movimento
    movimento = MovimentoEstoque(**movimento_data.dict())
    db.add(movimento)
    
    # Atualizar estoque do produto
    if movimento_data.tipo == "ENTRADA":
        produto.quantidade_atual += movimento_data.quantidade
    elif movimento_data.tipo == "SAIDA":
        produto.quantidade_atual -= movimento_data.quantidade
    
    db.commit()
    db.refresh(movimento)
    return movimento

@router.get("/produtos/estoque-baixo", response_model=List[ProdutoList])
def produtos_estoque_baixo(db: Session = Depends(get_db)):
    """Listar produtos com estoque baixo"""
    produtos = db.query(Produto).filter(
        and_(
            Produto.estoque_atual <= Produto.estoque_minimo,
            Produto.ativo == True
        )
    ).all()
    for p in produtos:
        try:
            if p.fornecedor_id:
                f = db.query(Fornecedor).filter(Fornecedor.id == p.fornecedor_id).first()
                p.fornecedor_nome = f.nome if f else None
            else:
                p.fornecedor_nome = None
        except Exception:
            p.fornecedor_nome = None
    return produtos

@router.post("/produtos/{produto_id}/ajuste-estoque")
def ajustar_estoque(
    produto_id: int,
    novo_estoque: int,
    motivo: str = "Ajuste manual",
    db: Session = Depends(get_db)
):
    """Ajustar estoque de um produto"""
    produto = db.query(Produto).filter(Produto.id == produto_id).first()
    if not produto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produto não encontrado"
        )
    
    if novo_estoque < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Estoque não pode ser negativo"
        )
    
    estoque_anterior = produto.quantidade_atual
    diferenca = novo_estoque - estoque_anterior
    
    if diferenca != 0:
        # Criar movimento de ajuste
        tipo = "ENTRADA" if diferenca > 0 else "SAIDA"
        quantidade = abs(diferenca)
        
        movimento = MovimentoEstoque(
            item_id=produto_id,
            tipo=tipo,
            quantidade=quantidade,
            motivo=motivo,
            observacoes=f"Ajuste de estoque: {estoque_anterior} → {novo_estoque}"
        )
        db.add(movimento)
        
        # Atualizar estoque do produto
        produto.quantidade_atual = novo_estoque
        db.commit()
    
    return {
        "message": "Estoque ajustado com sucesso",
        "estoque_anterior": estoque_anterior,
        "novo_estoque": novo_estoque,
        "diferenca": diferenca
    }